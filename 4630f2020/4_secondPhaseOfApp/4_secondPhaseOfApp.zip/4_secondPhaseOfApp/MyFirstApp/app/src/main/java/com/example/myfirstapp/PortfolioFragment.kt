package com.example.myfirstapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.fragment.findNavController
import kotlinx.android.synthetic.main.fragment_portfolio.*
import kotlinx.android.synthetic.main.fragment_portfolio.view.*
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.utils.ColorTemplate
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.PieEntry
import java.util.*
import kotlin.collections.ArrayList


/**
 * A simple [Fragment] subclass as the portfolio destination in the navigation.
 */
//tried to use code from https://stackoverflow.com/questions/60169560/mpandroid-piechart-in-kotlin
class PortfolioFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.piechart)

        val pieChart = view?.findViewById<PieChart>(R.id.pieChart)

        val listPie = ArrayList<PieEntry>()


        listPie.add(PieEntry(1501f, "Apple"))
        listPie.add(PieEntry(1645f, "Tesla"))
        listPie.add(PieEntry(1578f, "Google"))
        listPie.add(PieEntry(1695f, "Nvidia"))
        val dataSet = PieDataSet(listPie, "Number Of Accounts")

        dataSet.setDrawIcons(false)
        dataSet.sliceSpace = 3f
        dataSet.selectionShift = 5f
        dataSet.setColors(*ColorTemplate.COLORFUL_COLORS)

        val data = PieData(dataSet)
        data.setValueTextSize(11f)
        if (pieChart != null) {
            pieChart.data = data
        }
        pieChart?.highlightValues(null)
        pieChart?.invalidate()
        pieChart?.animateXY(5000, 5000)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_portfolio, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<Button>(R.id.previous).setOnClickListener {
            findNavController().navigate(R.id.action_fragment_portfolio_to_fragment_more)
        }

    }

}

