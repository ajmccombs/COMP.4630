I couldn't finish the whole assignment.


I got the buttons to navigate through the different fragments.

I tried to implement a Pie chart for the portfolio, but I couldnt find that much resources for
kotlin language using the MPAndroidChart library. I also couldn't figure out how to change from
a fragment to an activity, and maybe that's because I still don't really understand the difference
between them.

For the weather implementation, I just ran out of time to implement.
